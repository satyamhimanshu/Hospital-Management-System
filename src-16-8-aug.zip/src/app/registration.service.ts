import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http : HttpClient) { }

  public loginUserFromRemote(user:User):Observable<any>{
    console.log("loginfromremote");
    console.log(user.email, user.password);
    // console.log(this._http.post<any>("http://localhost:9095/login", user));
    return this._http.post<any>("http://localhost:8080/login", user);
  }

  public registerUser(user:User):Observable<any>{
    return this._http.post("http://localhost:8080/registeruser", user);
  }
}
