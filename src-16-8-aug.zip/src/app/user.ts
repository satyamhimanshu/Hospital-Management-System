import { ThrowStmt } from "@angular/compiler";

export class User {
    id:number;
    email:string;
    password:string;
    firstName:string;
    lastName:string;
    dob:String;
    mobile:String;
    aadhar:string;
    gender:string;
    address:string;

    constructor(){}
}
