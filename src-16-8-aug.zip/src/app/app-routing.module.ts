import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { ContactComponent } from './contact/contact.component';
import { DetailsComponent } from './details/details.component';
import { FaqsComponent } from './faqs/faqs.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { LogoutComponent } from './logout/logout.component';
import { RegistrationComponent } from './registration/registration.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { SearchComponent } from './search/search.component';
import { UserComponent } from './user/user.component';

const routes: Routes = [
  {path:"", component:LoginComponent},
  {path:"loginsuccess", component:LoginsuccessComponent},
  {path:"registration", component:RegistrationComponent},
  {path:"search", component:SearchComponent},
  {path:"confirm", component:ConfirmationComponent},
  {path:"approval", component:UserComponent},
  {path:"details", component:DetailsComponent},
  {path:"contact", component:ContactComponent},
  {path:"admin", component:AdminloginComponent},
  {path:"logout", component:LogoutComponent},
  {path:"recoverpassword", component:ResetpasswordComponent},
  {path:"faq", component:FaqsComponent},
  {path:"about", component:AboutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }