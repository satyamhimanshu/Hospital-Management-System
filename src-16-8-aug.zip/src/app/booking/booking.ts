export class Booking {

    id:number;
	id_user:number;
	id_hospital:number;
	date_time:string;
	symptoms:string;
	applicationNumber:string;
	bedNo:string;
	status:number;

    constructor(){}
}

