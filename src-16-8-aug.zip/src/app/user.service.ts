import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient , HttpParams} from '@angular/common/http';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  private baseUrl="http://localhost:8080/users";
  constructor(private http:HttpClient) { }

  getUser(id_hospital):Observable<User[]>
  {
    return this.http.get<User[]>(`${this.baseUrl}`,{params:{"id_hospital":id_hospital}})
  }


  // updateBooking(user:any):Observable<number>
  // {
  //   this.baseUrl="http://localhost:8080/updateBooking?bookid=5&decision=rejected";
  //   return this.http.get<number>(`http://localhost:8080/updateBooking?bookid=5&decision=rejected`);
  // }

  updateBooking(user:any):Observable<Object>{
    let params = new HttpParams();
    params = JSON.parse(JSON.stringify(user));
    console.log(JSON.stringify(params)+" here in updateBookingSErvice");
    return this.http.get("http://localhost:8080/updateBooking",{params:params});
    // return this.http.get("https://google.com");
  }

}
