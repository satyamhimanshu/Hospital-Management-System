import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from './admin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class AdminService {
  constructor(private _http : HttpClient) { }
admin:Admin;
  public loginUserFromRemote(admin:Admin):Observable<any>{
    console.log("loginfromremote");
    console.log(admin.email, admin.password);
    // console.log(this._http.post<any>("http://localhost:9095/login", user));
    return this._http.post<any>("http://localhost:8080/loginadmin", admin);
  }
  
}