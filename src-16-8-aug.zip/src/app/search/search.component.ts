import { Component, OnInit } from '@angular/core';
//import { FormBuilder } from '@angular/forms';
import { SearchService } from '../search.service';
import { Router } from '@angular/router';
import { FormArray, FormBuilder, FormControl } from '@angular/forms';
import { SharedServiceService } from '../SharedService/shared-service.service';
import { User } from '../user';
import { BookingService } from '../booking.service';
import { Booking } from '../booking/booking';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})

export class SearchComponent implements OnInit {

  searchForm:any;  
  hospital:any;
  msg = "";
  state:string='';
  district:string='';
  obj:any;
  symptom:any;
  form: any;
  symptoms: any = [
    "Fever",
    "Cold",
    "Dry Cough",
    "Tiredness",
    "Diarrhea",
    "Headache",
    "Chest Pain",
    "Loss of Taste and Smell",
    "Difficulty in Breathing",
    "Difficulty in Speech"
  ];
  statusMessage: string;
  statusMessageBad: string;
  submitErrorMessageHospital:string;
  submitErrorMessageSymptom:string;
  error:boolean=false;

  constructor(private fb:FormBuilder,private ss:SearchService, private _router:Router, private shared:SharedServiceService, private _service:BookingService) {

    this.searchForm=fb.group({
    id:[''],
    hospitalName:[''],
    state:[''],
    district:[''],
    pin:[''],
    });
   }
  

   //Symptoms Selected
   sympArray:any=[];

   //Hospital Selected
   hospitalSelected:any;
  
   onChange(symptom: string, isChecked: any) {
    const ss = (this.form.controls.name as FormArray);
    if (isChecked.checked) {
      ss.push(new FormControl(symptom));
    } else {
      const index = ss.controls.findIndex(x => x.value === symptom);
      ss.removeAt(index);
    }
    this.sympArray = ss.value;
    console.log(ss.value);
  }

  booking = new Booking();
  ctr:number;
  userAfterRefresh:any;
  bookingData:any;
  bookingStatus:any;
  allowSubmission:any;

  ngOnInit() {
    this.allowSubmission=true;

    this.form = this.fb.group({
      name: this.fb.array([])
    });

    var temp = localStorage.getItem("userObj");

    if(temp != null)
      this.obj = JSON.parse(temp);
    // this.obj = this.shared.getUserObject();

    if (!localStorage.getItem('foo')) { 
      localStorage.setItem('foo', 'no reload') 
      location.reload() 
    } else {
      localStorage.removeItem('foo') 
    }

    if(this.obj == undefined){
      this._router.navigate(["/"]);
    }
    
   
    var str = localStorage.getItem('userObj');
      if(str != null){
        this.userAfterRefresh = JSON.parse(str);
        console.log(this.userAfterRefresh.firstName + " UserAfterRefresh");
        console.log(str);
        this.shared.setUserObject(this.userAfterRefresh);
        this.obj = this.userAfterRefresh;
      }
      var book:Booking;
      
      // book = {"id":this.userAfterRefresh.id,"id_user":123, "id_hospital":0 ,"date_time": "", "symptoms":" ","applicationNumber":" ", "bedNo":"", "status":-5};
      // this._service.createBooking(book).subscribe();
      
      // this.shared.setUserObject(this.userAfterRefresh);
      this._service.getUserBooking(this.userAfterRefresh).subscribe(
        data => {console.log("Response received"),
        this.bookingData=data,
        console.log(this.bookingData.status,"bookingDataForGivenUser"),
        this.bookingStatus = this.bookingData.status;
        if(this.bookingData.status > 0){
          this.allowSubmission=false;
        }
        if(this.bookingStatus == -100){
          this.statusMessage = "Warning : Your Application is pending ! Resubmission will lead to deletion of your previous application";
        }
        if(this.bookingStatus == 0){
          this.statusMessageBad = "Your Application has been rejected, Kindly contact hospital or resubmit";
        }
        },
        error => {console.log("Exception occured")
        }
        )
    }


  details() 
  {
    // console.log(this.form.value);
    this._router.navigate(["details"]);
  }

  fnSubmit()
  {
    var state=this.state;
    var district=this.district;
   
    //alert(state+" and "+district);
    this.ss.findHospitalByStateDistrict(state,district).subscribe(data=>{this.hospital=data});
    // alert(this.state);
    // alert(this.district+":"+this.state);
  }

  onChange1($event:any)
  {
  const hospitalName=$event.target;
  // console.log(hospitalName.value);
  this.hospitalSelected=hospitalName.value;
  console.log(this.hospitalSelected);
  // alert(hospitalName);
  }

confirm(){
  // alert(this.sympArray);
  console.log(this.hospitalSelected);
  if(this.hospitalSelected == undefined){
    console.error("Hospital not selected");
    this.submitErrorMessageHospital = "Hospital not selected";
    console.log(this.submitErrorMessageHospital);
    this.error = true;
  }
  else{
    this.submitErrorMessageHospital="";
    this.error = false;
  }
  if(this.sympArray.length == 0){
    console.error("Symptoms not selected");
    console.log(this.sympArray.length);
    this.submitErrorMessageSymptom = "Symptoms not selected";
    this.error = true;
  }
  else{
    this.submitErrorMessageSymptom = "";
    this.error = false;
  }
  if(this.hospitalSelected != undefined && this.sympArray != undefined && this.sympArray.length != 0){
    this.booking.applicationNumber = "HMS21-"+this.obj.id;
    this.booking.bedNo = "";
    this.booking.date_time = (new Date()).toString().substring(0,5);
    // this.booking.id=0;
    //Update hospital_id from the UI
    this.booking.id_hospital = this.hospitalSelected;
    this.booking.id_user = this.obj.id;
  
    this.booking.symptoms = this.sympArray.toString();
    this.booking.status = -100;
    // this.booking.id_hospital = this.hospitalSelected.split("_")[1];


    this._service.createBooking(this.booking).subscribe(
      data => {console.log("Response received"),
      console.log(this.booking," Booking")
      localStorage.setItem("bookingObj", JSON.stringify(this.booking));
      localStorage.setItem("bookingDataAvailable","true");
      },
      error => {console.log("Exception occured"),
      this.msg = error;
      }
      );
    this._router.navigate(["/confirm"]);
}
}}
