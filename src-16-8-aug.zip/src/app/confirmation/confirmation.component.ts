import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Booking } from '../booking/booking';
import { SharedServiceService } from '../SharedService/shared-service.service';
import { User } from '../user';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {

  constructor(private shared:SharedServiceService, private _router:Router) { }

  user:User;
  booking:Booking;
  dataAvailable:boolean = false;
  ngOnInit(): void {
    // alert("Hi");
    
    // this.user = this.shared.getUserObject();
    var localUser = localStorage.getItem("userObj");
    
    if(localUser != null){
    this.user = JSON.parse(localUser);}
    if(this.user == undefined){
      this._router.navigate(["/"]);
    }
    console.log(this.user.firstName);
    
    var tempBook = localStorage.getItem("bookingObj");
    if(tempBook != null){
      this.booking = JSON.parse(tempBook);
    }
    
  }

  detailsPage(){

    this._router.navigate(["/details"]);
  }

}
