import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SearchService {

  url:string='http://localhost:8080/search/';
  constructor(private http:HttpClient) {}

  getStatus()
  {
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
        
        var search=localStorage.getItem("search");
        observer.next(search);
      },100);
    });
    return myObservable;
  }



    readAllHospitals(){
      return this.http.get(this.url);

    }

    findHospitalByStateDistrict(state:string,district:string){
     
  // return  this.http.get(this.url+"/"+state+"/"+district);
    return  this.http.get(this.url+state+"/"+district);
      
    }

   }