import { ThrowStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  
  loggedIn:any;
  userName:any;
  adminLoggedIn:any=false;
  constructor(private _router:Router) { }

  ngOnInit(): void {
    this.loggedIn = localStorage.getItem("loggedIn");
    this.adminLoggedIn = localStorage.getItem("adminLoggedIn");
    var user = localStorage.getItem("userObj");
    if(user != null){
    this.userName = (JSON.parse(user).firstName + " " + JSON.parse(user).lastName).toUpperCase();
    }
  }

  adminLogin(){
    this._router.navigate(["/admin"]);
  }

  logout(){
    localStorage.clear();
    this.loggedIn=false;
    this._router.navigateByUrl("/logout", { skipLocationChange: true })
  }

  contact(){
    this._router.navigate(["/contact"]);
  }

  send(){
    this._router.navigate(["/details"]);
  }
}
