import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Booking } from './booking/booking';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private _http : HttpClient) { }

  public createBooking(booking:Booking):Observable<any>{
    console.log("loginfromremote");
    console.log(booking);
    // console.log(this._http.post<any>("http://localhost:9095/login", user));
    return this._http.post<any>("http://localhost:8080/saveBookingDetails", booking);
  }

  //error
  public getUserBooking(user):Observable<any>{
    // console.log("getUserBooking");
    return this._http.get<any>("http://localhost:8080/getBookingDetail",{params:user});
  }

}
