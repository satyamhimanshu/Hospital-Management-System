import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { NavbarComponent } from './navbar/navbar.component';
import { NgxCaptchaModule } from 'ngx-captcha';
import { ReactiveFormsModule } from '@angular/forms';
import { ReCaptchaModule } from 'angular-recaptcha3';
import { SearchComponent } from './search/search.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { UserComponent } from './user/user.component';
import { DetailsComponent } from './details/details.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ContactComponent } from './contact/contact.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { LogoutComponent } from './logout/logout.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { ResetpasswordComponent } from './resetpassword/resetpassword.component';
import { FaqsComponent } from './faqs/faqs.component';
import { AboutComponent } from './about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegistrationComponent,
    LoginsuccessComponent,
    NavbarComponent,
    SearchComponent,
    ConfirmationComponent,
    UserComponent,
    DetailsComponent,
    ContactComponent,
    AdminloginComponent,
    LogoutComponent,
    SidenavComponent,
    ResetpasswordComponent,
    FaqsComponent,
    AboutComponent
     ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,

    ReCaptchaModule.forRoot({
      invisible: {
          sitekey: '6Lf89sgbAAAAAEQqgCXdsNS9LUk0cFxSEcfcKGPJ', 
      },
      normal: {
          sitekey: '6Lf89sgbAAAAAEQqgCXdsNS9LUk0cFxSEcfcKGPJ', 
      },
      language: 'en'
  }),
     NgbModule,
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
