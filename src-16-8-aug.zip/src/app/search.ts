export class Search {
    id:number=0;
    hospitalName:string="";
    state:string="";
    district:string="";
    pin:number=700101;
}
