import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
import { SharedServiceService } from '../SharedService/shared-service.service';
import { ThrowStmt } from '@angular/compiler';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = new User();
  msg:string;
  msgSuccess:any;
  users:User;

  constructor(private _service:RegistrationService, private _router:Router, private shared:SharedServiceService) { }

  ngOnInit(): void {
    var log = localStorage.getItem("loggedIn");
    if(log == "true"){
      this._router.navigateByUrl("/details", {skipLocationChange:true});
    }
    
  }

  registerModal(){
    // document.querySelector('.bg-modal').style.display = 'flex';
  }


  

  loginUser(){
    console.log("Hello, Button Clicked!");
    console.log(this.user.email, this.user.password);
    this._service.loginUserFromRemote(this.user).subscribe(
    data => {console.log("Response received"),
    this.users=data,
    this.shared.setUserObject(this.users),
    localStorage.setItem("userObj", JSON.stringify(this.users)),
    localStorage.setItem("loggedIn","true"),
    console.log(this.users,"users"),
    this._router.navigate(["/search"])
    },
    error => {console.log("Exception occured"),
      this.msg = "Bad credentials! Please enter valid email and password"
    }
    );
  }

  show = false;


  register(){
    // this.bgmodal = "bgmodal-def";
    this.show = !this.show;
    console.log("Registration Initiated");
    // this._router.navigate(["/registration"]);
  }


  registerFromModal(){
    // this.bgmodal = "bgmodal-def";
    this.show = !this.show;
    console.log("Registration Initiated");
    // this._router.navigate(["/registration"]);

    this._service.registerUser(this.user).subscribe(
      data=>{
        this.msgSuccess = "Registration Successful";
        // alert(this.msg);
        data=>console.log(data)
        
    },
    error=> {
      console.log("Exception occured");
      this.msg=error.error;
      // console.log(error.)
      // console.log(this.message+" This is the error!");
    })}

  hide(){
    this.show = !this.show;
  }
  recover(){
    this._router.navigateByUrl("/recoverpassword",{skipLocationChange:true});
  }

}
