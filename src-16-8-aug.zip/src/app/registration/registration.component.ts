import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';


@Component({
  selector: 'registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user = new User();
  msg='';
  constructor(private _service:RegistrationService, private _router:Router) { }

  ngOnInit(): void {
  }

  loginUser(){
    console.log("Hello, Button Clicked!");
    console.log(this.user.email, this.user.password);
    this._service.loginUserFromRemote(this.user).subscribe(
    data => {console.log("Response received"), 
    this._router.navigate(["/loginsuccess"])
    },
    error => {console.log("Exception occured"),
    console.log("Exception occured");
      // this.msg = "Bad credentials! Please enter valid email and password"
    }
    );
  }

  register(){
    console.log(this.user.email, this.user.password, this.user.mobile);
    console.log("Registration Initiated");
    // this._router.navigate(["/registration"]);
    this._service.registerUser(this.user).subscribe(
      data=>{
        this.msg = "Registration Successful";
        // alert(this.msg);
        data=>console.log(data)
        
    },
    error=> {
      console.log("Exception occured");
      this.msg=error.error;
      // console.log(error.)
      // console.log(this.message+" This is the error!");
    }
    );
  }

}