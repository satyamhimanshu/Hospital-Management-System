import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { SharedServiceService } from '../SharedService/shared-service.service';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { BookingService } from '../booking.service';
import { identifierModuleUrl, ThrowStmt } from '@angular/compiler';
import { DomSanitizer } from '@angular/platform-browser';
import { UpdateUserDetailsService } from '../update-user-details.service';
import { Booking } from '../booking/booking';
import { HospitalService } from '../hospital.service';
import { Hospital } from '../hospital';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  constructor(private shared : SharedServiceService, private _router:Router, private bookingservice:BookingService,private updatedetailsservice:UpdateUserDetailsService, private hospitalservice : HospitalService) { }
  
  user:User;//used
  booking:Booking;//used
  localUser:User;//used
  hospital:Hospital;
  tempUser:any;
  bookingData:any;
  bookingStatus:any;
  show:any;
  formInput:any;
  currEditItem:any;
  modalData:String="Default";
  downloadLink:any;
  button:String;
  isUserDataLoaded:boolean=false;
  isBookingDataLoaded:boolean=false;
  isHospitalDataLoaded:boolean=false;
  updateMessage:String;
  isUpdateConfirmationLoaded:boolean=false;

ngOnInit(): void {
    var str = localStorage.getItem("userObj");
      if(str != null){
        this.localUser = JSON.parse(str);
        this.shared.setUserObject(this.localUser);
        this.isUserDataLoaded = true;
      }
      this.isUserDataLoaded = true;
      console.log(this.localUser+" Local User from local storage");
      // this.user = this.shared.getUserObject();

      if(this.localUser == undefined){
      this._router.navigate(["/"]);
      }
      this.tempUser = {"id":this.localUser.id};
      // console.log(this.tempUser, " this.tempUser");
      this.bookingservice.getUserBooking(this.localUser).subscribe(
      data => {console.log("Response received"),
      this.booking=data,
      // this.downloadLink = "http://localhost:45/users/" + this.booking.id + ".pdf",
      console.log(this.booking," - bookingDataForGivenUser"),
      this.updateStatusApplication(this.booking),
      this.isBookingDataLoaded=true,

      this.hospitalservice.getHospitalById(this.booking.id_hospital).subscribe(data=>{
        this.hospital = data,
        console.log(this.hospital+" Hospital data"),
        this.isHospitalDataLoaded=true
      });

      },
      error => {console.log("Exception occured")
      }
      );
}


goToBookingPage(){
  this._router.navigate(["/search"]);
}



updateStatusApplication(bookingData){
      if(bookingData == null || bookingData == undefined){
          this.bookingStatus = "Not Applied";
      }
      if(bookingData.status > 0){
        this.bookingStatus = "Approved";
        // this.downloadLink = this.domSanitizer.bypassSecurityTrustResourceUrl("http://localhost\5.pdf");
        this.downloadLink = "http://localhost:45/users/"+bookingData.id+".pdf"
        this.show = true;
      }
      else if(bookingData.status == 0){
        this.bookingStatus = "Rejected";
        this.show = false;
      }
      else if(bookingData.status == -1){
        this.bookingStatus = "Not Applied";
        this.show = false;
      }
      else{
        this.bookingStatus = "Pending";
      }
}
  
updateToDb(event){
      this.button = event.target.attributes.value.value;
      this.updatedetailsservice.updateDetails({"field":this.button.toLowerCase(), "value":this.formInput, "id":this.localUser.id}).subscribe(data=>{
        console.log(data," updateToDb data"),
        this.updateMessage = "Successfully Updated";
        this.isUpdateConfirmationLoaded=true;
      }, 
      error=>{
        console.log(error);
        this.updateMessage = "Error writing to database";
      }
      )
      if(this.button == "Aadhar"){
        console.log("Aadhar ",this.formInput)
        this.localUser.aadhar = this.formInput;
        localStorage.setItem("userObj", JSON.stringify(this.localUser));
      }
      if(this.button == "Email" ){
        console.log("Email ",this.formInput)
        this.localUser.email = this.formInput;
        localStorage.setItem("userObj", JSON.stringify(this.localUser));
      }
      if(this.button == "Address"){
        console.log("Address ",this.formInput)
        this.localUser.address = this.formInput;
        localStorage.setItem("userObj", JSON.stringify(this.localUser));
      }
      if(this.button == "Mobile"){
        console.log("Mobile ",this.formInput)
        this.localUser.mobile = this.formInput;
        localStorage.setItem("userObj", JSON.stringify(this.localUser));
      }
}
  
updateModal(event:any){
    console.log(event.target.attributes.value.value);
    if(event.target.attributes.value.value == "aadhar"){
      this.modalData = "Aadhar";
    }
    if(event.target.attributes.value.value == "address"){
      this.modalData = "Address";
    }
    if(event.target.attributes.value.value == "mobile"){
      this.modalData = "Mobile";
    }
    if(event.target.attributes.value.value == "email"){
      this.modalData = "Email";
    }
  }
}