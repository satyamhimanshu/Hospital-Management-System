import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
import { SharedServiceService } from '../SharedService/shared-service.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  user = new Admin();
  msg:string="";

  users:Admin=new Admin();

  constructor(private _service:AdminService, private _router:Router, private shared:SharedServiceService) { }

  ngOnInit(): void {

  }

  loginUser(){
    localStorage.clear();
    console.log("Hello, Button Clicked!");
    console.log(this.user.email, this.user.password);
    this._service.loginUserFromRemote(this.user).subscribe(
    data => {console.log("Response received"),
    localStorage.setItem("loggedIn","true"),
    this.users=data,
    localStorage.setItem('admin',JSON.stringify(data)),
    console.log(this.users,"admin"),
    this._router.navigateByUrl("/approval")
    },
    error => {console.log("Exception occured"),
      this.msg = "Bad credentials! Please enter valid email and password"
    }
    );
 
  }

}