export class Admin {
    id:number;
    hospital_id:number;
    name:string;
    mobile:string;
    email:string;
    password:string;
}
