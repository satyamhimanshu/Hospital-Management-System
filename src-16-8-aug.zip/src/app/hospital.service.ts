import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Hospital } from './hospital';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HospitalService {

  constructor(private http:HttpClient) { }
  url:string='http://localhost:8080/hospital';
  baseUrl:string='http://localhost:8080/update'
  tempurl:string;

  //culprit no 1
  getCartItemsByCustomerId(id:any)
  {
    console.log(id+"gghjj");
    return this.http.get(this.url+"/id/"+id);
  }
  
  modifyCart(hospital:any)
  {
    console.log(hospital);
    return this.http.put(this.baseUrl,hospital);
  }
  //culprit
  getHospitalById(id:any):Observable<any>
  {
    return this.http.get<any>(this.url+"/"+id);
  }

  modifyBed(hospital_id:any,total_bed:any,occupied_bed:any)
  {
  
   this.tempurl=this.baseUrl+"/"+hospital_id+"/"+total_bed+"/"+occupied_bed;
   console.log(occupied_bed+"son");
    return this.http.put(this.tempurl,null);
  }
}