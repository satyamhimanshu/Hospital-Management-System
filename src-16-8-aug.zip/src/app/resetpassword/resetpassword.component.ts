import { Component, OnInit } from '@angular/core';
import { ResetpasswordService } from '../resetpassword.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {

  constructor(private passwordservice:ResetpasswordService) { }
  
  password:any;
  email:any;
  aadhar:any;

  ngOnInit(): void {
  }
   
  msg:any;
  msgSuccess:any;

  recover(){
    console.log("Password Reset Initiated");
    this.msg="";
    this.msgSuccess="";
    this.passwordservice.resetpassword({"password":this.password, "email":this.email, "aadhar":this.aadhar}).subscribe(
      data=>{
        // console.log(data+" this is data");
        this.msgSuccess = "Password changed successfully";
      },
      error=>{
        this.msg = "Invalid Details Provided";
      }
      
    );
  }

}
