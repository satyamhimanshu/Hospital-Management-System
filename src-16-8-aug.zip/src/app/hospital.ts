export class Hospital {
    id_hospital:number;
    hospitalName:string;
    district:string;
    state:string;
    pin:number;
    total_bed:number;
    occupied_bed:number
}