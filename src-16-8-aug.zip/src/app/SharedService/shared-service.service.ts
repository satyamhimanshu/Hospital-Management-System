import { Injectable } from '@angular/core';
import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {
  user:string;
  obj:User;
  constructor() { }


  setUserObject(obj){
    this.obj = obj;
    console.log(this.obj);
  }

  getUserObject(){
    return this.obj;
  }
}
