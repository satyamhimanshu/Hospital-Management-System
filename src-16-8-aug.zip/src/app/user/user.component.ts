import { formatCurrency } from '@angular/common';
import { Component, OnInit , ViewChild} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { User } from '../user';
import { UserService } from '../user.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { HostListener } from '@angular/core';
import { combineLatest } from 'rxjs';
import { HospitalService } from '../hospital.service';
import { Admin } from '../admin';
import { Hospital } from '../hospital';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})

export class UserComponent implements OnInit {
  users:any[]=[];
  counter:number=0;
  admin:Admin=new Admin;
  total_bed:number;
  cartItems:any;
  id_hospital:number;
  adminId:any;
  occupied_bed:number;
  hospitalName;
  modalTotalBed:any;
  modalOccupiedBed:any;
  hospital:any;
  msg: string;
  msg2: string;
  msg3: string;
  // hospital:any;
  constructor(private userservice : UserService, private modalService: NgbModal, private hospitalService:HospitalService) { }

  ngOnInit(): void {

    var c=localStorage.getItem("admin");
    if( c != null){
      this.id_hospital = JSON.parse(c).hospital_id;
      console.log(this.id_hospital +" Hospital ID");}

    this.userservice.getUser(this.id_hospital).subscribe((data:any[])=>{
    this.users=data;
    });
    
    
    if(c!=null){
      this.admin = JSON.parse(c);
      this.adminId = this.admin.id;
      console.log(this.adminId+" admin ID");
    }

    // console.log(this.admin.hospital_id+" This is admin");
    this.hospitalService.getCartItemsByCustomerId(this.admin.hospital_id).subscribe((data)=>{

      console.log(data);
      this.cartItems = data;
      this.id_hospital = this.cartItems[0].id_hospital;
      console.log(data + "data");
      this.total_bed = this.cartItems[0].total_bed;
      this.occupied_bed=this.cartItems[0].occupied_bed;
    })

    this.hospitalService.getHospitalById(this.admin.hospital_id).subscribe((data)=>
    {
    console.log(data+"yo");
    this.hospital=data;
    this.hospitalName = this.hospital.hospitalName;
    console.log(this.hospital);
    localStorage.setItem("hospital",this.hospital);
    })
    // console.log("users ",this.users);
  
  }

    
  patient_id:any;
  state:any;
  currentObj:any;
  currentObjDecision:any;
  currentUser:any;
  currentButton:any;
  done:any=true;
  userList:any[]=[];

  hello(event:any, index){
    this.state = event.target.value.split("-");
    this.currentObj = this.state[0];
    this.currentObjDecision = this.state[1];
    // console.log(this.currentObj+this.currentObjDecision+" This.state");
    // this.currentUser = this.users[this.currentObj-1];
    // console.log(index);
    // console.log(this.users[index]);
    this.currentUser = this.users[index];
    this.currentUser['decision'] = this.currentObjDecision;
    console.log(this.currentUser.booking.id+" "+this.currentUser.decision);
    // alert(JSON.stringify(this.currentUser.booking));
    // console.log(this.users[0]+" This.users");
    // this.currentUser = this.users[this.currentObj-1];
    // console.log(this.currentUser);
    // this.done=false;
    this.userList[index] = {"bookid":this.currentUser.booking.id, "decision":this.currentUser.decision};
  }


  closeResult = '';
  event:any;
  statusMessage:String;
  bedUpdateMessage:String;
  // open(content, event) {

  //   this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
  //     this.closeResult = `Closed with: ${result}`;
  //   }, (reason) => {
  //     this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  //   });
  //   this.state = event.target.value.split("-");
  //   this.currentObj = parseInt(this.state[0]);
  //   this.currentButton = this.state[1];
  //   this.currentUser = this.users[this.currentObj];
  //   console.log(this.currentUser);
  //   this.changeMsg();
  // }

  writeToDb(){
    console.log("Data written to database");
    console.log(this.userList);
    for (let i = 0; i < this.userList.length; i++) { 
    this.userservice.updateBooking(this.userList[i]).subscribe(data=>{
      this.statusMessage = "Update completed";
    });
    console.log("Complete writing into db");}
  }
  
  changeMsg(){
    this.msg = "Do you want to accept registration of "+this.currentUser.patient.firstName + " " + this.currentUser.patient.lastName;
    this.msg2 = "Patient Id : "+ this.currentUser.patient.id;
    this.msg3 = "Symptoms : "+ this.currentUser.booking.symptoms;
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  // fnUpdate()
  // {
  
  //   alert(JSON.stringify(this.hospital));
  //   this.hospitalservice.modifyCart(this.hospital).subscribe((data)=>
  //   {
  //     console.log(data);
  //     alert(JSON.stringify(data));
  //     console.log(this.total_bed);
  //   });
  // }
  // fnMo()
  // {
 
  // }

  logData(){
    this.hospital.total_bed = this.modalTotalBed;
    this.hospital.occupied_bed = this.modalOccupiedBed;
    console.log("Current Hospital Data",this.hospital);

    this.hospitalService.modifyCart(this.hospital).subscribe((data)=>{
      console.log(data);
      this.occupied_bed = this.modalOccupiedBed,
      this.total_bed = this.modalTotalBed,
      this.bedUpdateMessage="Resource Successfully updated!"
    });
  }
 }

