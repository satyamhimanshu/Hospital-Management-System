package com.group6.hms.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.group6.hms.booking.dao.BookingDao;
import com.group6.hms.booking.entity.Booking;

@Service
public class BookingService {
	
	@Autowired
	BookingDao bookingDao;

	public int saveBooking(Booking booking) {
		
		int deleted = deleteBooking(booking);
		System.out.println("Object deleted : "+deleted);
		int result = bookingDao.create(booking);
		System.out.println("Now created "+booking);
//		System.out.println(booking.getEmail());
		return result;
	}
	
	public int deleteBooking(Booking booking) {
		int result = bookingDao.delete(booking.getId_user());
		return result;
	}
	
	public Booking getUserBooking(long user_id) {
		return bookingDao.read(user_id);
	}
	
	public Booking getBookingByBookingId(long bookid) {
		
		return bookingDao.readByBookId(bookid);
	}
	
	public int updateStatus(int bookingid, int status){
		
		return bookingDao.update(bookingid, status);
	}
	
	
	
}