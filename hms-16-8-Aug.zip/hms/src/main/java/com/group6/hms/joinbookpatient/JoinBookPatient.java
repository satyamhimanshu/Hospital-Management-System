package com.group6.hms.joinbookpatient;

import com.group6.hms.booking.entity.Booking;
import com.group6.hms.patient.entity.Patient;

public class JoinBookPatient {

	private Booking booking;
	private Patient patient;

	public JoinBookPatient(Booking booking, Patient patient) {

		this.booking = booking;
		this.patient = patient;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

}
