package com.group6.hms.hospital.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.hospital.entity.Hospital;

public class HospitalRowMapper implements RowMapper<Hospital> {
	
	Hospital hospital = null;
	
	@Override
	public Hospital mapRow(ResultSet rs, int rowNum) throws SQLException {
		hospital = new Hospital(rs.getLong(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getLong(5),
				rs.getInt(6), rs.getInt(7));
		return hospital;
	}
}
