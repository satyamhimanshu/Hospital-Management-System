package com.group6.hms.admin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.admin.entity.Admin;

public class AdminRowMapper implements RowMapper<Admin>{
Admin admin=null;
    @Override
    public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
         admin =new Admin(rs.getLong(1),rs.getLong(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
        return admin;
    }
  }
