package com.group6.hms.booking.dao;

import java.sql.ResultSet;

import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.booking.entity.Booking;

public class BookingRowMapper implements RowMapper<Booking>{

	@Override
	public Booking mapRow(ResultSet rs, int rowNum) throws SQLException {
		long id = rs.getLong(1);
		int id_user = rs.getInt(2);
		int id_hospital = rs.getInt(3);
		String date_time = rs.getString(4);
		String symptoms = rs.getString(5);
		String applicationNumber = rs.getString(6);
		String bedNo = rs.getString(7);
		int status = rs.getInt(8);
		
		return new Booking(id, id_user, id_hospital, date_time, symptoms, applicationNumber, bedNo, status);
	}
}