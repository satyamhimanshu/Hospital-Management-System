package com.group6.hms.registration.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.group6.hms.patient.dao.PatientDao;
import com.group6.hms.patient.entity.Patient;

@Service
public class RegistrationService {
	
	@Autowired
	PatientDao daoImpl;
	
	public Patient fetchUserByEmailId(String email) {
		Patient result = daoImpl.read(email);
		return result;
	}

	public Patient saveUser(Patient user) {
		daoImpl.create(user);
		Patient patient = daoImpl.read(user.getEmail());
		System.out.println(user.getEmail());
		System.out.println(patient);
		return patient;
	}

	public Patient fetchUserByEmailIdAndPassword(String tempEmail, String tempPass) {
		Patient patient = daoImpl.read(tempEmail, tempPass);
		return patient;
	}
	
}
