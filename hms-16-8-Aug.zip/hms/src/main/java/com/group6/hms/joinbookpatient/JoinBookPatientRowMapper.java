package com.group6.hms.joinbookpatient;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.booking.entity.Booking;
import com.group6.hms.patient.entity.Patient;

public class JoinBookPatientRowMapper implements RowMapper<JoinBookPatient> {

	@Override
	public JoinBookPatient mapRow(ResultSet rs, int rowNum) throws SQLException {
		long id = rs.getLong(1);
		String firstName = rs.getString(2);
		String lastName = rs.getString(3);
		String email = rs.getString(4);
		String password = rs.getString(5);
		String mobile = rs.getString(6);
		String aadhar = rs.getString(7);
		String dob = rs.getString(8);
		String address = rs.getString(9);
		long id_book = rs.getLong(10);
		int id_user = rs.getInt(11);
		int id_hospital = rs.getInt(12);
		String date_time = rs.getString(13);
		String symptoms = rs.getString(14);
		String applicationNumber = rs.getString(15);
		String bedNo = rs.getString(16);
		int status = rs.getInt(17);
		return new JoinBookPatient(
				new Booking(id_book, id_user, id_hospital, date_time, symptoms, applicationNumber, bedNo, status),
				new Patient(id, firstName, lastName, email, password, mobile, aadhar, dob, address));
	}

}
