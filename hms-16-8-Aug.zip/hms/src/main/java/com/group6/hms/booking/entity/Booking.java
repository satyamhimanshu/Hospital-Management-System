package com.group6.hms.booking.entity;

public class Booking {

	private long id;
	private int id_user;
	private int id_hospital;
	private String date_time;
	private String symptoms;
	private String applicationNumber;
	private String bedNo;
	private int status;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_user() {
		return id_user;
	}

	public void setId_user(int id_user) {
		this.id_user = id_user;
	}

	public int getId_hospital() {
		return id_hospital;
	}

	public void setId_hospital(int id_hospital) {
		this.id_hospital = id_hospital;
	}

	public String getDate_time() {
		return date_time;
	}

	public void setDate_time(String date_time) {
		this.date_time = date_time;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getBedNo() {
		return bedNo;
	}

	public void setBedNo(String bedNo) {
		this.bedNo = bedNo;
	}

	@Override
	public String toString() {
		return "Booking [id=" + id + ", id_user=" + id_user + ", id_hospital=" + id_hospital + ", date_time="
				+ date_time + ", symptoms=" + symptoms + ", applicationNumber=" + applicationNumber + ", bedNo=" + bedNo
				+ "]";
	}

	public Booking(long id, int id_user, int id_hospital, String date_time, String symptoms, String applicationNumber,
			String bedNo, int status) {
		super();
		this.id = id;
		this.id_user = id_user;
		this.id_hospital = id_hospital;
		this.date_time = date_time;
		this.symptoms = symptoms;
		this.applicationNumber = applicationNumber;
		this.bedNo = bedNo;
		this.status = status;
	}

}