package com.group6.hms.admin.entity;

public class Admin {
	private long id;
	private long hospital_id;
	private String name;
	private String mobile;
	private String email;
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(long id, long hospital_id, String name, String mobile, String email, String password) {
		super();
		this.id = id;
		this.hospital_id = hospital_id;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getHospital_id() {
		return hospital_id;
	}

	public void setHospital_id(long hospital_id) {
		this.hospital_id = hospital_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}
}