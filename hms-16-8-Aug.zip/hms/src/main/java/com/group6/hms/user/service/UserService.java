package com.group6.hms.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.group6.hms.booking.dao.BookingRowMapper;
import com.group6.hms.joinbookpatient.JoinBookPatient;
import com.group6.hms.joinbookpatient.JoinBookPatientRowMapper;
import com.group6.hms.patient.dao.PatientRowMapper;
import com.group6.hms.patient.entity.Patient;

@Service
public class UserService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<JoinBookPatient> read(int id_hospital) {
//    	System.out.println("inside read()");
//        String sql = "select u.first_name, u.last_name, u.email from patient u inner join booking b where u.id=b.id_user;";
		String sql = "SELECT * FROM PATIENT INNER JOIN BOOKING ON patient.id = booking.id_user WHERE booking.status < 0 AND booking.id_hospital = ?";
		return jdbcTemplate.query(sql, new JoinBookPatientRowMapper(), id_hospital);
	}

//    public Patient read(Long id) {
//        return jdbcTemplate.queryForObject(
//                "select u.id,u.first_name,u.dob,u.mobile,u.email,u.aadhar,u.address from users u inner join booking b where u.id=b.id_user and u.id=?",
//                new PatientRowMapper(), id);
//    }
}