package com.group6.hms.admin.generatepdf;

import java.io.File;
import java.io.IOException;

import com.group6.hms.booking.entity.Booking;
import com.group6.hms.patient.entity.Patient;

public class GeneratePdf {
	
	public static void generate(Patient patient, Booking booking) {
//		String name = patient.getFirstName() + " " +patient.getLastName(); 
		systemCall(patient.getFirstName(), patient.getLastName(), booking.getId());
	}
	
	private static void systemCall(String fname, String lname,  long booking_id) {
		try {
			Process process = Runtime.getRuntime().exec(
			        "cmd.exe /c start generatePdf.py "+fname+" "+lname+" "+booking_id,
			        null,
			        new File("C:\\xampp\\htdocs\\users"));
		 
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
}
