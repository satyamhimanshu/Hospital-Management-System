package com.group6.hms.patient.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.patient.entity.Patient;

public class PatientRowMapper implements RowMapper<Patient> {

	@Override
	public Patient mapRow(ResultSet rs, int rowNum) throws SQLException {

		long id = rs.getLong(1);
		String firstName = rs.getString(2);
		String lastName = rs.getString(3);
		String email = rs.getString(4);
		String password = rs.getString(5);
		String mobile = rs.getString(6);
//		System.out.println(mobile);
		String aadhar = rs.getString(7);
		String dob = rs.getString(8);
		String address = rs.getString(9);

		Patient patient = new Patient(id, firstName, lastName, email, password, mobile, aadhar, dob, address);

		return patient;
	}
}