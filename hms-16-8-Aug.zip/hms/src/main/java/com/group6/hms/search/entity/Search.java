package com.group6.hms.search.entity;

public class Search {
	private Long id;
	private String hospitalName;
	private String state;
	private String district;
	private Long pin;
	
	
	public Search() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Search(Long id, String hospitalName, String state, String district, Long pin) {
		super();
		this.id = id;
		this.hospitalName = hospitalName;
		this.state = state;
		this.district = district;
		this.pin = pin;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public Long getPin() {
		return pin;
	}
	public void setPin(Long pin) {
		this.pin = pin;
	}
	
	@Override
	public String toString() {
		return "Search [id=" + id + ", hospitalName=" + hospitalName + ", state=" + state + ", district=" + district
				+ ", pin=" + pin + "]";
	}
}
