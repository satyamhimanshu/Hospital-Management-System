package com.group6.hms.admin.dao;

import java.util.List;

import com.group6.hms.admin.entity.Admin;
import com.group6.hms.hospital.entity.Hospital;

public interface AdminDao {
	Admin read(String email, String password);

	// List<Hospital> getAllHospital(Admin admin);
	public List<Hospital> read();

	public Hospital read(Long id);

	public List<Hospital> cartByAdminId(Long id);

	public int update(Hospital hospital);

	public int update1(long hospital_id, int total_bed, int occupied_bed);
}
