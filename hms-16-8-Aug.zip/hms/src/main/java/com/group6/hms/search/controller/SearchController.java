package com.group6.hms.search.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.group6.hms.booking.entity.Booking;
import com.group6.hms.booking.service.BookingService;
import com.group6.hms.joinbookpatient.JoinBookPatient;
import com.group6.hms.patient.entity.Patient;
import com.group6.hms.search.entity.Search;
import com.group6.hms.search.service.SearchService;
import com.group6.hms.user.service.UserService;

@RestController
@CrossOrigin("http://localhost:4200/")
public class SearchController {

	@Autowired
	private SearchService ss;

	@Autowired
	private UserService us;
	
	@Autowired
	private BookingService bs;

	@GetMapping("/")
	public String home() {
		return "Hello world";
	}

	@GetMapping("/search")
	public List<Search> getAllSearchs() {
		return ss.read(); // function call
	}

	@GetMapping("/search/id/{id}")
	public Search findEmployeeById(@PathVariable Long id) {
		Search search = null;
		try {
			search = ss.read(id);
		} catch (EmptyResultDataAccessException erde) {
			search = new Search();
		}
		return search;
	}

	@GetMapping("/search/{state}")
	public List<Search> findSearchById(@PathVariable String state) {
		List<Search> search = null;
		try {
			search = ss.read(state);
		} catch (EmptyResultDataAccessException erde) {
			search = new ArrayList<Search>();
		}
		return search;
	}

	@GetMapping("/search/{state}/{district}")
	public List<Search> findSearchByStateDistrict(@PathVariable String state, @PathVariable String district) {
		List<Search> search = null;
		try {
			search = ss.read(state, district);
			// search=es.read(district);
		} catch (EmptyResultDataAccessException erde) {
			search = new ArrayList<Search>();
		}
		return search;
	}

	@PostMapping("/search")
	public int addSearch(@RequestBody Search Search) {
		return ss.create(Search);
	}

	@PutMapping("/search")
	public int modifySearch(@RequestBody Search Search) {
		return ss.update(Search);
	}

	@DeleteMapping("/search/{id}")
	public int removeSearch(@PathVariable Long id) {
		return ss.delete(id);
	}

	@GetMapping("/users")
	public List<JoinBookPatient> getAllUsers(@RequestParam int id_hospital) {
//		System.out.println(us.read());
		System.out.println(id_hospital);
		return us.read(id_hospital);
	}
	
	@GetMapping("/getBookingDetail")
	public Booking getUserBooking(@RequestParam long id) throws Exception{
		System.out.println(id);
		Booking booking = bs.getUserBooking(id);
		if(booking == null) {
			throw new Exception("No Booking found for user - "+id);
		}
		return booking;
	}
}