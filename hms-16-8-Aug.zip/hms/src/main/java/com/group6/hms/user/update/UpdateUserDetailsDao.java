package com.group6.hms.user.update;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class UpdateUserDetailsDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int updateAadhar(String field, String value, int patient_id) {
		String sql = "UPDATE patient SET "+field+"= ? where id = ?";
		return jdbcTemplate.update(sql, value, patient_id);
	}
}
