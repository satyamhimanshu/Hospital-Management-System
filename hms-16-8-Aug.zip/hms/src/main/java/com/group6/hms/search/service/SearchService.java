package com.group6.hms.search.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.group6.hms.patient.dao.PatientRowMapper;
import com.group6.hms.patient.entity.Patient;
import com.group6.hms.search.dao.SearchRowMapper;
import com.group6.hms.search.entity.Search;

@Service
public class SearchService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int create(Search Search) {
		String sql = "INSERT INTO hospitallist VALUES(?,?,?,?,?)";
		return jdbcTemplate.update(sql, Search.getId(), Search.getHospitalName(), Search.getState(),
				Search.getDistrict(), Search.getPin());
	}

	public List<Search> read() {
		return jdbcTemplate.query("SELECT * FROM hospitallist", new SearchRowMapper());
	}

	public Search read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM hospitallist WHERE id_hospital=?", new SearchRowMapper(), id);
	}
//		public int update(Search Search) {
//			String sql="UPDATE Search SET hospitalName=?, state=?, district=?, pin=? WHERE id_hospital=?";
//			return jdbcTemplate.update(sql, Search.getId(), Search.getHospitalName(), Search.getState(), Search.getDistrict(), Search.getPin());
//		}
//		public int delete(Long id) {
//			String sql="DELETE FROM hospitallist WHERE id_hospital=?";
//			return jdbcTemplate.update(sql, id);
//		}

	public List<Search> read(String state) {
		return jdbcTemplate.query("SELECT * FROM hospitallist WHERE state=? ", new SearchRowMapper(), state);
	}

	public List<Search> read(String state, String district) {
		return jdbcTemplate.query("SELECT * FROM hospitallist WHERE state=? and district=?", new SearchRowMapper(),
				state, district);
	}

	public int update(Search Search) {
		String sql = "UPDATE Search SET hospitalName=?, state=?, district=?, pin=? WHERE id_hospital=?";
		return jdbcTemplate.update(sql, Search.getId(), Search.getHospitalName(), Search.getState(),
				Search.getDistrict(), Search.getPin());
	}

	public int delete(Long id) {
		String sql = "DELETE FROM hospitallist WHERE id_hospital=?";
		return jdbcTemplate.update(sql, id);
	}

	// Manish Implementation
	public Patient fetchUserByEmailIdAndPassword(String email, String password) {
		String sql = "SELECT * FROM hospitallist WHERE email = ?";
		PatientRowMapper mapper = new PatientRowMapper();
		Patient result = jdbcTemplate.queryForObject(sql, mapper);
		return result;
	}

	public Patient getPatientByPatientId(long id) {
		String sql = "SELECT * FROM patient WHERE id = ?";
		Patient result = jdbcTemplate.queryForObject(sql, new PatientRowMapper(), id);
		return result;
	}

}