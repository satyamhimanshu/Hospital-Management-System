package com.group6.hms.user.update;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:4200")
public class UpdateUserDataController {
	
	@Autowired
	UpdateUserDetailsDao dao;
	
	@GetMapping("/updateuserdetails")
	public int updateUserDetails(@RequestParam String field, @RequestParam String value, @RequestParam int id) {
		
		System.out.println(field+" "+value+" "+id);
		
		return dao.updateAadhar(field, value, id);
		
	}
}
