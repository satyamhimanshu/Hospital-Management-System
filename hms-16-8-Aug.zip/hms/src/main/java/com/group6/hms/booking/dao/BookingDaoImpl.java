package com.group6.hms.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.group6.hms.booking.entity.Booking;

@Component
public class BookingDaoImpl implements BookingDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public int create(Booking booking) {
		String sql = "INSERT INTO booking(id_user, id_hospital, date_time, symptoms, applicationNumber, bedNo, status) value(?, ?, ?, ?, ?, ?, ?)";
		return jdbcTemplate.update(sql, booking.getId_user(), booking.getId_hospital(), booking.getDate_time(),
				booking.getSymptoms(), booking.getApplicationNumber(), booking.getBedNo(), booking.getStatus());
	}

	@Override
	public int update(int bookingid, int status) {
		String sql = "UPDATE booking set status = ? WHERE id = ?";
		return jdbcTemplate.update(sql, status, bookingid);
	}

	@Override
	public int delete(int id) {
		String sql = "DELETE FROM booking WHERE id_user = ?";
		return jdbcTemplate.update(sql, id);
	}

	@Override
	public Booking read(Long id){
		String sql = "SELECT * FROM booking WHERE id_user = ?";
		try {
		Booking booking = jdbcTemplate.queryForObject(sql, new BookingRowMapper(), id);
		return booking;
		}
		catch (Exception e) {
			System.out.println("No Booking for current user - "+id);
		}
		return null;
	}
	
	@Override
	public Booking readByBookId(Long id) {
		String sql = "SELECT * FROM booking WHERE id = ?";
		return jdbcTemplate.queryForObject(sql, new BookingRowMapper(), id);
	}

	@Override
	public List<Booking> read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking read(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking read(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
