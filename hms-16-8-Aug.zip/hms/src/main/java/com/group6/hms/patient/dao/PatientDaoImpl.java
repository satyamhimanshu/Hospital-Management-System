package com.group6.hms.patient.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.group6.hms.patient.entity.Patient;

@Component
public class PatientDaoImpl implements PatientDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int create(Patient patient) {
//		String sql = "INSERT INTO patient VALUE (?,?,?,?,?,?,?)";
//		String sql = "insert into patient(first_name, last_name, email, password, mobile, aadhar, dob, address) value(?, ?, ?, ?, ?, ?, ?, ?)";
		String sql = "insert into patient(first_name, last_name, email, password, mobile, aadhar, dob, address) value(?, ?, ?, ?, ?, ?, ?, ?);";
		System.out.println(patient);

		int result = jdbcTemplate.update(sql, patient.getFirstName(), patient.getLastName(), patient.getEmail(),
				patient.getPassword(), patient.getMobile(), patient.getAadhar(), patient.getDob(), patient.getAddress());
	
		System.out.println("Number of rows changed : " + result);
		return result;
	}

	@Override
	public int update(Patient patient) {
		String sql = "UPDATE PATIENT SET firstName = ?, lastName = ?, email = ?, password = ? WHERE id = ?";
		int result = jdbcTemplate.update(sql, patient.getFirstName(), patient.getLastName(), patient.getEmail(),
				patient.getPassword(), patient.getId());
		return result;
	}

	@Override
	public int delete(int id) {
		return 0;
	}

	@Override
	public Patient read(Long id) {
		String sql = "SELECT * FROM patient WHERE id=?";
		PatientRowMapper mapper = new PatientRowMapper();
		Patient patient = jdbcTemplate.queryForObject(sql, mapper, id);
		return patient;
	}

	@Override
	public List<Patient> read() {
		String sql = "SELECT * FROM patient";
		PatientRowMapper mapper = new PatientRowMapper();
		List<Patient> result = jdbcTemplate.query(sql, mapper);
		return result;
	}

	@Override
	public Patient read(String email) {
		String sql = "SELECT * FROM patient WHERE email = ?";
		PatientRowMapper mapper = new PatientRowMapper();
		Patient result = null;
		try {
			result = jdbcTemplate.queryForObject(sql, mapper, email);
		} catch (Exception e) {

		}
		return result;
	}

	@Override
	public Patient read(String email, String password) {
		String sql = "SELECT * FROM patient WHERE email = ? AND password = ?";
		PatientRowMapper mapper = new PatientRowMapper();
		Patient patient = jdbcTemplate.queryForObject(sql, mapper, email, password);
		return patient;
	}

}