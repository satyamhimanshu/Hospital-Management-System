package com.group6.hms.passwordrecover;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class RecoverPasswordDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int recoverPassword(String email, String aadhar, String password) {
		String sql = "UPDATE patient SET password = ? WHERE email = ? AND aadhar = ?";
		return jdbcTemplate.update(sql, password, email, aadhar);
	}
	
}
