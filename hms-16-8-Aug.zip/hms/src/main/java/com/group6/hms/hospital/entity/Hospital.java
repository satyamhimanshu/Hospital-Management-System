package com.group6.hms.hospital.entity;


public class Hospital {
	private Long id_hospital;
	private String hospitalName;
	private String district;
	private String state;
	private Long pin;
	private int total_bed;
	private int occupied_bed;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Long getPin() {
		return pin;
	}

	public void setPin(Long pin) {
		this.pin = pin;
	}

	public int getTotal_bed() {
		return total_bed;
	}

	public void setTotal_bed(int total_bed) {
		this.total_bed = total_bed;
	}

	public int getOccupied_bed() {
		return occupied_bed;
	}

	public void setOccupied_bed(int occupied_bed) {
		this.occupied_bed = occupied_bed;
	}

	public void setDistrict(String district) {
		this.district = district;
	}


	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospital(Long id_hospital, String hospitalName, String district, String state, Long pin, int total_bed,
			int occupied_bed) {
		super();
		this.id_hospital = id_hospital;
		this.hospitalName = hospitalName;
		this.district = district;
		this.state = state;
		this.pin = pin;
		this.total_bed = total_bed;
		this.occupied_bed = occupied_bed;
	}

	public Long getId_hospital() {
		return id_hospital;
	}

	public void setId_hospital(Long id_hospital) {
		this.id_hospital = id_hospital;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getDistrict() {
		return district;
	}
}