package com.group6.hms.booking.dao;

import java.util.List;

import com.group6.hms.booking.entity.Booking;

public interface BookingDao {
	
	int create(Booking booking);

	int update(int bookingid, int status);

	int delete(int id);

	Booking read(Long id);

	Booking readByBookId(Long id);
	
	List<Booking> read();

	Booking read(String email);

	Booking read(String email, String password);
	
}
