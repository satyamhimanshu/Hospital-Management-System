package com.group6.hms.admin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.group6.hms.admin.dao.AdminDao;
import com.group6.hms.admin.entity.Admin;

@Service
public class AdminService {
	@Autowired
	AdminDao dao;

	public Admin fetchAdminByEmailIdAndPassword(String tempEmail, String tempPass) {
		Admin admin = dao.read(tempEmail, tempPass);
		return admin;
	}
}