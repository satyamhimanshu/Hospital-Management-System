package com.group6.hms.passwordrecover;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:4200")
public class PasswordRecovery {
	
	@Autowired
	RecoverPasswordDao dao;
	
	@GetMapping("/recoverpassword")
	public int recoverPassword(@RequestParam String email, @RequestParam String aadhar, @RequestParam String password) throws Exception {

		int response = dao.recoverPassword(email, aadhar, password);
		
		if(response == 0) {
			throw new Exception("Invalid Details Provided");		
		}
		
		return response;
		
	}
	
}
