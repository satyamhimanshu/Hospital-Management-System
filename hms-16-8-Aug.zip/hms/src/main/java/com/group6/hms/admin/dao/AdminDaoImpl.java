package com.group6.hms.admin.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.group6.hms.admin.entity.Admin;
import com.group6.hms.hospital.dao.HospitalRowMapper;
import com.group6.hms.hospital.entity.Hospital;

@Component
public class AdminDaoImpl implements AdminDao{
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Override
    public Admin read(String email, String password) {
        String sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
        AdminRowMapper arm=    new AdminRowMapper();
        Admin admin = jdbcTemplate.queryForObject(sql, arm, email, password);
        return admin;
    }/*
    @Override
    public List<Hospital> getAllHospital(Admin admin) {
        // TODO Auto-generated method stub
        String sql="Select * from hospitallist h inner join admin a where h.id_hospital=a.hospital_id ;";
        return null;
    }*/
    @Override
    public List<Hospital> read() {
        // TODO Auto-generated method stub
        return jdbcTemplate.query("SELECT * FROM hospitallist", new HospitalRowMapper());
        
    }
    @Override
    public Hospital read(Long id) {
        return jdbcTemplate.queryForObject("SELECT * FROM hospitallist WHERE id_hospital=?", new HospitalRowMapper(), id);
    }
    
    @Override
    public List<Hospital> cartByAdminId(Long id) {
        return jdbcTemplate.query("SELECT * FROM hospitallist WHERE id_hospital=?", new HospitalRowMapper(), id);
        
    }
    @Override
    public int update(Hospital hospital) {
        // TODO Auto-generated method stub
        return jdbcTemplate.update("update hospitallist set total_bed=?,occupied_bed=? where id_hospital=?",hospital.getTotal_bed(),hospital.getOccupied_bed(),hospital.getId_hospital());
    }
    @Override
    public int update1(long hospital_id,int total_bed, int occupied_bed) {
        // TODO Auto-generated method stub
        return jdbcTemplate.update("update hospitallist set total_bed=?,occupied_bed=? where id_hospital=?",total_bed,occupied_bed,hospital_id);
    }
}