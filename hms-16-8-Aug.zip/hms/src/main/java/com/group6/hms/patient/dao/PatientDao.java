package com.group6.hms.patient.dao;

import java.util.List;

import com.group6.hms.patient.entity.Patient;

public interface PatientDao {
	
	int create(Patient patient);
	
	int update(Patient patient);
	
	int delete(int id);
	
	Patient read(Long id);
	
	List<Patient> read();
	
	Patient read(String email);
	
	Patient read(String email, String password);
}
