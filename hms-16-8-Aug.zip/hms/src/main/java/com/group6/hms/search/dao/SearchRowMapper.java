package com.group6.hms.search.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.group6.hms.search.entity.Search;

public class SearchRowMapper implements RowMapper<Search>
{
	@Override
	public Search mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Search(rs.getLong(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getLong(5));
	}
}
