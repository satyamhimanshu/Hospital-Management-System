package com.group6.hms.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.group6.hms.admin.dao.AdminDao;
import com.group6.hms.hospital.entity.Hospital;

@Service
public class HospitalService {
	@Autowired
	AdminDao adm;

	public List<Hospital> findBedItemsByAdminId(Long id) {
//		System.out.println(id);
		return adm.cartByAdminId(id);
	}

	public int update(Hospital hospital) {
		return adm.update(hospital);
	}

	public Hospital read(Long id) {
		return adm.read(id);
	}

	public int update1(Long hospital_id, int total_bed, int occupied_bed) {
		return adm.update1(hospital_id, total_bed, occupied_bed);
	}
}