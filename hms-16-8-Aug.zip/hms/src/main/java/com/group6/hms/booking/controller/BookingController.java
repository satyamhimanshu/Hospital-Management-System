package com.group6.hms.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.group6.hms.admin.generatepdf.GeneratePdf;
import com.group6.hms.booking.entity.Booking;
import com.group6.hms.booking.service.BookingService;
import com.group6.hms.email.EmailController;
import com.group6.hms.patient.entity.Patient;
import com.group6.hms.search.service.SearchService;

@RestController
public class BookingController {

	@Autowired
	BookingService service;

	@Autowired
	SearchService searchService;

	// This function first checks if user has already booked, if previous booking
	// record is found, first it has to be deleted
	@PostMapping("/saveBookingDetails")
	@CrossOrigin(origins = "http://localhost:4200")
	public int saveBooking(@RequestBody Booking booking) throws Exception {

		System.out.println(booking + " Got booking");
		int result = service.saveBooking(booking);
		return result;
	}

	@GetMapping("/updateBooking")
	@CrossOrigin(origins = "http://localhost:4200")
	public int updateBooking(@RequestParam int bookid, @RequestParam String decision) {
		System.out.println(bookid + " " + decision);
		Booking book = service.getBookingByBookingId(bookid);
		Patient patient = searchService.getPatientByPatientId(book.getId_user());
		int dec = 0;
		if (decision.equals("accept")) {
			dec = 5;
			System.out.println("Approved : 5");
			
			
			String message = "Hello User, your booking id - "+bookid+" has been accepted. Please go to account details section to download your admission letter. \n Thanks & Regards \n Admin";
			EmailController.sendEmail(message, "Accepted", patient.getEmail());
			GeneratePdf.generate(patient, book);
			System.out.println("Pdf Generation Initiated");
		} else if (decision.equals("reject")) {
			dec = 0;
			String message = "Hello User, sorry to inform you that your booking id - "+bookid+" has been rejected. Please go to account section to reapply. \nThanks & Regards \nAdmin";
			EmailController.sendEmail(message, "Rejected", patient.getEmail());
			System.out.println("Rejected : 0");
		} else if (decision.equals("not applied")) {
			dec = -1;
			System.out.println("Not Applied : -1");
		} else {
			dec = -100;
		}
		return service.updateStatus(bookid, dec);
	}

}