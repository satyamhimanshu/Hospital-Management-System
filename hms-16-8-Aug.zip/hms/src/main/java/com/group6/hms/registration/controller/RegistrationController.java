package com.group6.hms.registration.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.group6.hms.email.EmailController;
import com.group6.hms.patient.entity.Patient;
import com.group6.hms.registration.service.RegistrationService;

@RestController
public class RegistrationController {
	
	@Autowired
	RegistrationService service;
	
	@PostMapping("/registeruser")
	@CrossOrigin(origins = "http://localhost:4200")
	public Patient registerUser(@RequestBody Patient user) throws Exception {
		String tempEmail = user.getEmail();
//		System.out.println(user.getPassword()+" entry into java class");
//		System.out.println(user +" This is the temporary Email I got");
//		System.out.println("if loop got executed");
		if (tempEmail != null) {
//			System.out.println("if loop didn't get executed");
			Patient userObj = service.fetchUserByEmailId(tempEmail);
//			System.out.println(userObj+" This exists in system");
//			System.out.println(userObj);
			if (userObj != null) {
				throw new Exception("User with " + tempEmail + " already exists!");
			}
		}
		Patient userObj = null;
		EmailController.sendEmail("Your email is registered!","HMS Registration Successfull",tempEmail);
		userObj = service.saveUser(user);
		return userObj;
	}

	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public Patient loginUser(@RequestBody Patient user) throws Exception {	
		String tempEmail = user.getEmail();
		String tempPass = user.getPassword();
		Patient userObj = null;
		if (tempEmail != null && tempPass != null) {
			userObj = service.fetchUserByEmailIdAndPassword(tempEmail, tempPass);
			System.out.println("Hello");
		}
		if (userObj == null) {
			throw new Exception("Username and password combination not found!");
		}
		return userObj;
	}
}