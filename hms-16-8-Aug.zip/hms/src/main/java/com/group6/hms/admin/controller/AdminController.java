package com.group6.hms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.group6.hms.admin.entity.Admin;
import com.group6.hms.admin.service.AdminService;
import com.group6.hms.hospital.entity.Hospital;
import com.group6.hms.hospital.service.HospitalService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {
	@Autowired
	AdminService adm;
	@Autowired
	HospitalService hs;

	@PostMapping("/loginadmin")
	public Admin loginUser(@RequestBody Admin admin) throws Exception {
//		System.out.println("Here I am");
		String tempEmail = admin.getEmail();
		String tempPass = admin.getPassword();
		Admin adminObj = null;
		if (tempEmail != null && tempPass != null) {
			adminObj = adm.fetchAdminByEmailIdAndPassword(tempEmail, tempPass);
//			System.out.println("Hello");
		}
		if (adminObj == null) {
			throw new Exception("Username and password combination not found!");
		}
		return adminObj;
	}

	@GetMapping("/hospital/id/{id}")
	public List<Hospital> findOrdersByCustomer(@PathVariable Long id) {
//		System.out.println(id);
		return hs.findBedItemsByAdminId(id);

	}

	@PutMapping("/update")
	public int modifyOrder(@RequestBody Hospital hospital) {
		return hs.update(hospital);
	}

	@GetMapping("/hospital/{id}")
	public Hospital findCartById(@PathVariable Long id) {
		return hs.read(id);
	}

	@PutMapping("/update/{hospital_id}/{total_bed}/{occupied_bed}")
	public int modifyBed(@PathVariable Long hospital_id, @PathVariable int total_bed, @PathVariable int occupied_bed) {
		return hs.update1(hospital_id, total_bed, occupied_bed);
	}

}